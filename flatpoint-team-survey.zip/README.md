# FlatPoint Team Survey
Корпоративная анкета UraganAPART × FLATP( )INT.
Статическая страница: `index.html`.

Важно: отправка ответов ожидает endpoint `/api/submit`.
